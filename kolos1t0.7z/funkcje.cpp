#include "funkcje.h"

Struktura* stworzTablice(int rozmiar, const Struktura& prototyp) {
    Struktura* tablica = new Struktura[rozmiar];
    for (int i = 0; i < rozmiar; ++i) {
        tablica[i] = prototyp;
    }
    return tablica;
}

void zapiszTabliceDoPliku(const char* nazwaPliku, int rozmiar, const Struktura& prototyp) {
    FILE* plik = fopen(nazwaPliku, "w");
    if (plik == NULL) {
        std::cerr << "Nie mozna otworzyc pliku do zapisu" << std::endl;
        return;
    }

    fprintf(plik, "%d\n", rozmiar);
    for (int i = 0; i < rozmiar; ++i) {
        fprintf(plik, "%d %f\n", prototyp.i, prototyp.d);
    }

    fclose(plik);
}

Struktura* odczytajZPliku(const char* nazwaPliku) {
    FILE* plik = fopen(nazwaPliku, "r");
    if (plik == NULL) {
        std::cerr << "Nie mozna otworzyc pliku do odczytu" << std::endl;
        return nullptr;
    }

    int rozmiar;

    fscanf(plik, "%d\n", &rozmiar);
    Struktura* tablica = new Struktura[rozmiar];
    for (int i = 0; i < rozmiar; ++i) {
        fscanf(plik, "%d %lf\n", &tablica[i].i, &tablica[i].d);
    }

    fclose(plik);
    return tablica;
}