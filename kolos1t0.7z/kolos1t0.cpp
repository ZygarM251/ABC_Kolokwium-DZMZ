﻿#include <cstdio>
#include "funkcje.h"

int main() {
    const char* nazwaPliku = "tablica.txt";
    Struktura prototyp = { 1, 3.14 };
    //duze Z w ASCII to 90
    Struktura* tworzonaTablica = stworzTablice(90, prototyp);

    zapiszTabliceDoPliku(nazwaPliku, 90, prototyp);

    Struktura* odczytanaTablica = odczytajZPliku(nazwaPliku);

    bool czySaIdentyczne = true;
    for (int i = 0; i < 90; ++i) {
        if (tworzonaTablica[i].i != odczytanaTablica[i].i || tworzonaTablica[i].d != odczytanaTablica[i].d) {
            czySaIdentyczne = false;
            break;
        }
    }


    std::cout << "Czy sa identyczne?:\t";
    if (czySaIdentyczne) {
        std::cout << "Tak\n";
    }
    else {
        std::cout << "Nie\n";
    }

    delete[] tworzonaTablica;
    delete[] odczytanaTablica;

    return 0;
}