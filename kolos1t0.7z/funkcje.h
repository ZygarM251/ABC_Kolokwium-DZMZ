#pragma once

#include <cstdio>
#include <iostream>

struct Struktura {
    int i;
    double d;
};

Struktura* stworzTablice(int rozmiar, const Struktura& prototyp);
void zapiszTabliceDoPliku(const char* nazwaPliku, int rozmiar, const Struktura& prototyp);
Struktura* odczytajZPliku(const char* nazwaPliku);